# Amiga Test Kit: The Amiga system test suite

## Structure of the distributed ZIP file

- **AmigaTestKit.adf**
  A bootable disk image of the test suite.

- **AmigaTestKit**
  A version runnable from the CLI or Workbench (with accompanying .info file)

- **debug/**
  Debug symbols for diagnosing problems with the test suite
